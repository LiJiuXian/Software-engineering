/**************************************************************************************************/
/* Copyright (C) USTC, 2014-2015                                                                  */
/*                                                                                                */
/*  FILE NAME             :  test.c                                                               */
/*  PRINCIPAL AUTHOR      :  LiJiuXian                                                            */                    
/*  SUBSYSTEM NAME        :  test                                                                 */
/*  MODULE NAME           :  test                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/22                                                           */
/*  DESCRIPTION           :  This is a test program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 * 
 * Created by LiJiuXian,2014/09/22
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include"menu.h"
#include "linktable.h"


int Help();

#define CMD_MAX_LEN 128
#define DESC_LEN    1024
#define CMD_NUM     10


/* menu program */
static tDataNode data[]=
{
    {NULL,"help","this is a help cmd",Help},
    {NULL,"version","menu Program v1.0",NULL}
};

tLinkTable * head = NULL;

main()
{
    head = CreateLinkTable();
    AddLinkTableNode(head,(tLinkTableNode *)&data[0]);
    AddLinkTableNode(head,(tLinkTableNode *)&data[1]);

    /* cmd line begins */
    while(1)
    {
        char cmd[CMD_MAX_LEN];
        printf("Input a cmd word->");
        scanf("%s",cmd);
        tDataNode *p=FindCmd(head,cmd);
        if(p == NULL)
        {
            printf("The cmd you put is wrong.\n"); 
            continue;
        }
        printf("%s - %s\n",p->cmd,p->desc);
        if(p->handler != NULL)
            {
                p->handler();
            }
    }
}

int Help()
{
    ShowAllCmd(head);
    return 0;

}













