This is a test program!

Build Procedure:

    $ gcc linktable.c menu.c test.c -o test
    $ ./test # you can input help or version cmd



